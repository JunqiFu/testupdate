/**
 * Created by Administrator on 2019/5/14.
 * ui 选择结构
 */
//选择分类
var botui = new BotUI('select-bot'), // 可更改内容  botui   delivery-bot
    address = '斐，是一个简单人，这是一个简单的网站，才开始入门希望你能持续关注我！'; //默认参数
var delays =1000;
var name = '';
var password = '';
// 开始
botui.message
    .bot('(｡･∀･)ﾉﾞ嗨，这是斐的个人网站！')
    .then(function () {
        return botui.action.button({
            delay: delays,
            action: [{
                text: '介绍',
                value: 'about'
            }, {
                text: '我要输入!',
                value: 'input'
            },
                {
                    text: '继续说!',
                    value: 'ohter'
                }]
        }).then(function (res) {
            if (res.value == 'input') {
                showInput();
            } else if (res.value == 'about') {
                botui.message.bot({
                    delay: delays,
                    content: address
                }).then(function(){
                     botui.message.add({
                        delay:delay*2,
                        type: 'embed',
                        content: 'img/cat/cat001.gif'
                    })
                }).then(end());
            } else {
                botui.message.bot({
                    delay: delays,
                    content: "我要继续说啦，没完没了的说！"
                }).then(showOhter());
            }
        });
    })

// 输入内容
var showInput = function (){
    botui.message
        .bot({
            loading:true,
            delay: delays*2,
            content: '你想说些什么？'
        })
        .then(function () {
            return botui.action.text({
                delay: delays,
                action: {
                    placeholder: '说说吧(☆▽☆)：'
                }
            })
        })
        .then(function (res) {
        // 判断输入内容关键字   用 || 标签 判断类似关键字  并且给出设定内容
          if (res.value == "日记"|| res.value == "看日记"|| res.value == "我的日记") {
             return botui.message
                .bot({
                    delay: delays / 2,
                    content: '你想看我的日记吗？'
                })
                .then(function () {
                    return botui.action.button({
                        delay: delays,
                        action: [{
                            text: '是的',
                            value: 'yes'
                        }, {
                            text: '错啦!',
                            value: 'no'
                        }]
                    })
                })
                 .then(function (res) {
                    if (res.value == 'yes') {
                        showDiary();
                    } else {
                        botui.message.bot({
                            delay: delays,
                            content: '日记内容错误啦！'
                        }).then(showInput());
                    }

                })
        }else if(res.value == "管理员") {
            return botui.message
                .bot({
                    delay: delays / 2,
                    content: '哎呀，你是管理员爸爸吗？'
                })
                .then(function () {
                    return botui.action.button({
                        delay: delays,
                        action: [{
                            text: '是的',
                            value: 'yes'
                        }, {
                            text: '不是!',
                            value: 'no'
                        }]
                    })
                })
                .then(function (res) {
                    if (res.value == 'yes') {
                        showPassword();
                    } else {
                        botui.message.bot({
                            delay: delays,
                            content: '(￢︿̫̿￢☆)不是管理员，输入管理干嘛，重新输！'
                        }).then(showInput());
                    }
                })
        }else if(res.value == "讲故事"|| res.value == "故事"||  res.value == "你的故事"){
            return botui.message
                .bot({
                    delay: delays / 2,
                    content: '你想听我讲故事吗？'
                })
                .then(function () {
                    return botui.action.button({
                        delay: delays,
                        action: [{
                            text: '是的',
                            value: 'yes'
                        }, {
                            text: '错啦!',
                            value: 'no'
                        }]
                    })
                })
                .then(function (res) {
                    if (res.value == 'yes') {
                        showStory();
                    } else {
                        botui.message.bot({
                            delay: delays,
                            content: '故事内容错啦！'
                        }).then(end());//结束
                    }

                })
        }else if(res.value == "音乐" || res.value == "听音乐" || res.value == "音乐热评" ){
              return botui.message
                  .bot({
                      delay: delays,
                      content: '哇哦，没想到你也喜欢音乐呢o(*￣▽￣*)ブ'
                  })
                  .then(function(){
                     botui.message.add({
                         delay: delays,
                         content: '选一个音乐类型，我们继续聊！(●"_"●)'
                     })
                  })
                  .then(function () {
                      return botui.action.button({
                          delay: delays,
                          action: [{
                              text: '流行',
                              value: 'Popular'
                          }, {
                              text: '摇滚',
                              value: 'Rock'
                          },
                          {
                              text: '民谣',
                              value: 'Ballad'
                          },
                          {
                              text: '影视原声',
                              value: 'Movies '
                          },
                          {
                              text: 'ACG',
                              value: 'ACG '
                          }]
                      })
                  })
                  .then(function (res) {
                      if (res.value == 'Popular') {
                          listenPopular();
                      } else if(res.value == 'Rock'){
                          listenRock();
                      } else if(res.value == 'Ballad'){
                          listenBallad();
                      }  else if(res.value == 'Movies'){
                          listenMovies();
                      }  else if(res.value == 'ACG'){
                          listenACG();
                      } else {
                          botui.message.bot({
                              delay: delays,
                              content: '没有更多内容啦，试试输入关键字 (●" v "●)',
                          }).then(showInput());
                      }
                  })

          }else if(res.value == "电影"||res.value == "说电影"||res.value == "推荐电影") {
            return botui.message
                .bot({
                    delay: delays,
                    content: '哈哈，终于说到我最喜欢的话题了！选一个电影类型继续聊哦'
                })
                .then(function () {
                    return botui.action.button({
                        delay: delays,
                        action: [{
                            text: '科幻电影',
                            value: 'Science'
                        }, {
                            text: '动作电影',
                            value: 'Action'
                        },
                        {
                            text: '爱情电影',
                            value: 'Love'
                        },
                        {
                            text: '动漫电影',
                            value: 'Animation '
                        },
                        {
                            text: '其他电影',
                            value: 'Other '
                        }]
                    })
                })
                .then(function (res) {
                    if (res.value == 'Science') {
                        showScience();
                    } else if(res.value == 'Action'){
                        showAction();
                    } else if(res.value == 'Love'){
                        showLove();
                    }  else if(res.value == 'Animation'){
                        showAnimation();
                    }  else {
                        botui.message.bot({
                            delay: delays,
                            content: '没有更多内容啦，试试输入关键字 (●" v "●)',
                        }).then(showInput());
                    }
                })
        }else if(res.value == "aaa"|| res.value == "abcd"|| res.value == "qwer"|| res.value == "admin"){
            return botui.message
                .bot({
                    delay: delays / 2,
                    content: '我暂时不能理解这句话╥﹏╥...！'
                }).then(showInput());

        }else if(res.value == "111"|| res.value == "123"|| res.value == "123456"|| res.value == "12345"||res.value == "321"){
            return botui.message
                .bot({
                    delay: delays / 2,
                    content: res.value+'这些数字有什么秘密呢 ？'
                })
                .then(showInput());

        }else if(res.value == ""){
            return botui.message
                .bot({
                    delay: delays / 2,
                    content: '你还没有输入内容哦！'
                })
                .then(showInput());

        }else if(res.value == "黄鑫"||res.value == "师傅鑫"|| res.value == "鑫"|| res.value == "小鑫鑫" || res.value == "鑫鑫"){
              return botui.message
                  .bot({
                      delay: delays / 2,
                      content: '哎，我知道你是谁'
                  }).then(function() {
                      botui.message.add({
                          loading: true,
                          delay: delays,
                          content: '你是我的女朋友啊'
                      })
                  }).then(function () {
                      botui.message.add({
                          loading: true,
                          delay: delays + 1000,
                          content: '不相信，我还有你的照片哦！！'
                      })
                  }).then(function (){
                      return botui.message.add({
                          type: 'embed',
                          content: 'img/180.png',
                          delay:delays*2
                      })

              }).then(function (){
                      botui.message.add({
                          loading: true,
                          delay: delays + 1000,
                          content: '哈哈,被骗到了吗？'
                      })

                  });
        }else {
            return botui.message
                .bot({
                    delay: delays,
                    content: '哎呀，我暂时不能理解这句话╥﹏╥...！你可以说关键词：音乐，电影，其他...'
                })
                .then(showInput());

        }
    });
}

// Ohter 其他废话模块
var showOhter = function() {
    botui.message
    .bot({
        loading: true,
        delay: delays,
        content: '废话模式开启！！( ‵▽′)ψ'
    })
    .then(function () {
        // 循环语句尝试
        for (var i = 1; i <5; i++) {
            botui.message.add({
                delay: delays*2,
                loading: true,
                content: '喜欢你！♥'
            });
            botui.message.add({
                human: true,
                delay: delays*2,
                content: '我也喜欢你！😘'
            });
            botui.message.add({
                delay: delays*2,
                loading: true,
                content: '超级喜欢你！'
            });
            botui.message.add({
                human: true,
                delay: delays*2,
                content: '超级超级喜欢你！'
            });
            delays++
        }
    });
    //结束对话
    end();
}
//======================用户模块
//管理员密码验证
    var showPassword = function(){
        botui.message.bot({
            delay: delays,
            content: '是爸爸，就来验证一下吧！'
        })
        .then(function () {
            return botui.action.text({
                delay: delays,
                action: {
                    placeholder: '密码是什么呢(☆▽☆)：'
                }
            })
        })
        .then(function (res) {
            // 判断输入内容关键字   用 || 标签 判断类似关键字  并且给出设定内容
            if (res.value == "admin1997"|| res.value == "管理员密码"|| res.value == "卜卜斐") {
                botui.message.bot({
                    delay: delays,
                    content: '哇，真的是爸爸哎！o(*￣▽￣*)ブ'
                });
                admin();
            }else if(res.value ==""){
                botui.message.bot({
                    delay: delays,
                    content: '哇，想蒙混过关吗，竟然什么都没输入，(╯▔皿▔)╯！,再给你一次机会！'
                }).then(showPassword());

            }else{
                botui.message.bot({
                    delay: delays,
                    content: '欺骗我弱小的心灵，简直是个禽兽，(￢︿̫̿￢☆)！'
                }).then(end());
            }
        })
    }

//管理员模块
    var admin = function(){
        botui.message.bot({
            delay: delays,
            content: '欢迎回家！！admin *^____^*'
        });
    }
       //======================音乐模块
// 流行
   var listenPopular = function(){
       botui.message.bot({
           delay: delays,
           content: '这是流行音乐模块'
       });
   }
//摇滚
   var listenRock = function (){
       botui.message.bot({
           delay: delays,
           content: '这是摇滚音乐模块'
       });
   }
//民谣
   var listenBallad = function (){
       botui.message.bot({
           delay: delays,
           content: '这是民谣音乐模块'
       });
   }
//影视原声
   var listenMovies = function (){
       botui.message.bot({
           delay: delays,
           content: '这是影视原声音乐模块'
       });
   }
// ACG
   var  listenACG = function(){
       botui.message.bot({
           delay: delays,
           content: '这是ACG音乐模块'
       });
   }

    //======================电影模块

// 科幻电影
    var showScience = function(){
        botui.message.bot({
            delay: delays,
            content: '这是科幻电影的内容！'
        });
    }
// 动漫电影
    var showAnimation =function(){
        botui.message.bot({
            delay: delays,
            content: '这是动作电影的内容！'
        });
    }
// 爱情电影
    var showLove =function(){
        botui.message.bot({
            delay: delays,
            content: '这是动作电影的内容！'
        });
    }
// 动作电影
    var showAction =function(){
        botui.message.bot({
            delay: delays,
            content: '这是动作电影的内容！'
        });
    }
//======================讲故事模块
// 故事内容
    var showStory = function(){
        botui.message.bot({
            delay: delays,
            content: '这是故事的内容！'
        });
    }
//======================日记内容模块
// 显示日记内容
   var showDiary = function(){

      botui.message.bot({
         delay: delays,
         content: '三行情书/ 5.15'
       }).then(function(){
            botui.message.add({
                loading:true,
                delay: delays+1000,
                content: '我有三行情书要写给你'
            })
          botui.message.add({
              delay: delays+2000,
              content: '必须要你给我研墨'
          })
          botui.message.add({
              delay: delays+3000,
              content:  '我来执笔'
          })

      }).then(function(){
          botui.message.add({
              delay: delays*3,
              content:  '每天都会和你在一起，希望能一直和你在一起！'
          })
      });
   }
//======================结束模块
// 结束对话
   var end = function(){
       botui.message.bot({
           delay: delays*2,
           content: '结束语！谢谢你，了解更多，持续关注吧！'
       })
   }

